meaningless gibberish to mysql \c
