SELECT author FROM classics;
SELECT DISTINCT author FROM classics;
