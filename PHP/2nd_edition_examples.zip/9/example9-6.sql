EXPLAIN SELECT * FROM accounts WHERE number='12345';
