<?php
$gn = getnext();
if ($finished == 1 OR $gn == 1) exit;
?>
