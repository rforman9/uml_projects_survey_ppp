<?php
if ($finished == 1 OR getnext() == 1) exit;
?>
