<script>
function displayItems()
{
	for (j = 0 ; j < displayItems.arguments.length ; ++j)
		document.write(displayItems.arguments[j] + "<br />")
}
</script>