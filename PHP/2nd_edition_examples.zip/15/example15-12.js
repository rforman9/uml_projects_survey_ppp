<script>
pets = ["Cat", "Dog", "Rabbit", "Hamster"]
document.write(pets.join()      + "<br />")
document.write(pets.join(' ')   + "<br />")
document.write(pets.join(' : ') + "<br />")
</script>