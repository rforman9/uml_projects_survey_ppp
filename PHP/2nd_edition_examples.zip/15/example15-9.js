<script>
balls = {"golf":   "Golf balls, 6",
		 "tennis": "Tennis balls, 3",
		 "soccer": "Soccer ball, 1",
		 "ping":   "Ping Pong balls, 1 doz"}

for (ball in balls)
	document.write(ball + " = " + balls[ball] + "<br />")
</script>