<script>
numbers = []

for (j=0 ; j<3 ; ++j)
{
	numbers.push(j);
	document.write("Pushed " + j + "<br />")
}

// Perform some other activity here
document.write("<br />")

document.write("Popped " + numbers.pop() + "<br />")
document.write("Popped " + numbers.pop() + "<br />")
document.write("Popped " + numbers.pop() + "<br />")
</script>
