<script>
numbers = []
numbers.push("One")
numbers.push("Two")
numbers.push("Three")

for (j = 0 ; j < numbers.length ; ++j)
	document.write("Element " + j + " = " + numbers[j] + "<br />")
</script>