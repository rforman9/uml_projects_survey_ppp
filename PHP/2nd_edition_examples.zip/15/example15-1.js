<script>
displayItems("Dog", "Cat", "Pony", "Hamster", "Tortoise")

function displayItems(v1, v2, v3, v4, v5)
{
	document.write(v1 + "<br />")
	document.write(v2 + "<br />")
	document.write(v3 + "<br />")
	document.write(v4 + "<br />")
	document.write(v5 + "<br />")
}
</script>