<script>
for (count = 1 ; count <= 12 ; ++count)
{
	document.write(count + " times 12 is " + count * 12 + "<br />");
}
</script>