<script>
if      (page == "Home")  document.write("You selected Home")
else if (page == "About") document.write("You selected About")
else if (page == "News")  document.write("You selected News")
else if (page == "Login") document.write("You selected Login")
else if (page == "Links") document.write("You selected Links")
</script>