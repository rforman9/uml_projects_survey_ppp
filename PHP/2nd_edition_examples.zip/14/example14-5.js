<script>
a = 1000
b = "1000"
if (a == b) document.write("1")
if (a === b) document.write("2")
</script>