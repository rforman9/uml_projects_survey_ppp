<script>
document.write(
	a <= 5 ?
	"a is less than or equal to 5" :
	"a is greater than 5"
)
</script>