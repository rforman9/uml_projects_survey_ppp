<script>
counter=0

while (counter < 5)
{
	document.write("Counter: " + counter + "<br />")
	++counter
}
</script>