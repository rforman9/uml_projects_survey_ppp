<script>
string = "The quick brown fox jumps over the lazy dog"
with (string)
{
	document.write("The string is " + length + " characters<br />")
	document.write("In upper case it's: " + toUpperCase())
}
</script>