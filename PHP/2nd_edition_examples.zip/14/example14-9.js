<script>
gn = getnext()
if (finished == 1 OR gn == 1) done = 1;
</script>