<?php
echo "Hello world";
?>

