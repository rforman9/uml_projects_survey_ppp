<?php
$author = "Alfred E Newman";

$out = <<<_END
This is a Headline

This is the first line.
This is the second.
- Written by $author.
_END;
?>