<?php
class User
{
	function User($param1, $param2)
	{
		// Constructor statements go here
	}
}
?>
