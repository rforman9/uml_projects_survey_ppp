function S(obj)
{
    return O(obj).style
}
